/*Yunika Upadhayaya 1001631183*/

#ifndef _MYLIB_H
#define _MYLIB_H

void ConvertDecimalToBinary(int decimal_number, int Array[]);
void PrintBinary(int Array[]);

#endif

