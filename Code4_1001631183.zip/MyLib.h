/*Yunika Upadhayaya 1001631183*/

#ifndef _MYLIB_H
#define _MYLIB_H

void ConvertDecimalToBinary(int convert_decimal);

#endif

